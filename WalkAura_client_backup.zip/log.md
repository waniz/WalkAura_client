# Introduction

After the events in Italy, when my notebook and all code base / templates were stolen I am starting from the scratch.

# Chapter 1: 12.09.2025 -
Create a basic pedometer access for Android

The working plugin started to work on 15.09.2025 (daughters bday)
